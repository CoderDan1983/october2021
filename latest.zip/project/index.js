//going where so many have gone before
function notMuchHasBeenDoneHere(){
	const roll=round(Math.random());
	return(roll);
}

class Romneyfied {
	constructor(name, age, power){
		this.name=name;
		this.age=age;
		this.power=power;
	}
}